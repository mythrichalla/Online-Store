
// Interface to be used in Validator class

public interface Acceptable 
{
	boolean isNonEmptyString (String s);
	boolean isPositiveInput (double d);
	
}
